import boto3
import json
import logging
from botocore.exceptions import ClientError, EndpointConnectionError

# configurar log
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# inicializar DynamoDB fora do handler (melhor performance)
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("resume-counter")


def lambda_handler(event, context):
    """Incrementa contador de visitas e retorna valor atualizado."""

    try:
        response = table.update_item(
            Key={"id": "visits"},
            UpdateExpression="ADD #count :incr",
            ExpressionAttributeNames={"#count": "count"},
            ExpressionAttributeValues={":incr": 1},
            ReturnValues="UPDATED_NEW",
        )

        count = int(response["Attributes"]["count"])
        logger.info(f"Contador atualizado para {count}")

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",  # habilita CORS
            },
            "body": json.dumps({"visits": count}),
        }

    except EndpointConnectionError as e:
        logger.error(f"Falha de conexão com DynamoDB: {e}")
        return {
            "statusCode": 503,
            "body": json.dumps({"error": "Falha de conexão com DynamoDB"}),
        }

    except ClientError as e:
        logger.error(f"Erro de cliente AWS: {e.response['Error']['Message']}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": e.response['Error']['Message']}),
        }

    except Exception as e:
        logger.exception("Erro inesperado na execução da Lambda")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}),
        }
